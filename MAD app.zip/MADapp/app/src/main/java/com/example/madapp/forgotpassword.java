package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;

public class forgotpassword extends AppCompatActivity {
    EditText emailEditText;
    Button backButton, resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgotpassword);

        emailEditText = findViewById(R.id.email_edittext);
        backButton = findViewById(R.id.button1);
        resetButton = findViewById(R.id.reset_button);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the behavior when the back button is clicked
                Intent intent = new Intent(forgotpassword.this, login.class); // Replace LoginActivity.class with the desired class to go back to
                startActivity(intent);
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();

                // Perform the reset password logic here
                if (!TextUtils.isEmpty(email)) {
                    // You can add logic here to reset the password for the provided email
                    // For example, sending a reset link to the provided email
                    Toast.makeText(forgotpassword.this, "Password reset request sent to " + email, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(forgotpassword   .this, "Please enter your email", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
