package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import java.util.Random;


import androidx.appcompat.app.AppCompatActivity;

public class inventory extends AppCompatActivity {
    private ArrayList<String> productsList;
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory);


        ListView productsListView = findViewById(R.id.inventory_list);
        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);

        productsList = new ArrayList<>();
        productsList.add("BHQ_11234");
        productsList.add("RDF_33456");
        productsList.add("ADF_22890");
        productsList.add("KIL_77856");
        productsList.add("IOP_99867");
        productsList.add("MAI_24356");

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, productsList);
        productsListView.setAdapter(adapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addProduct();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteProduct();
            }
        });
    }

    private void addProduct() {
        String[] randomProducts = {"ZWX_11234", "BWX_33456", "LET_22890", "WET_77856", "NNH_99867"};

        Random random = new Random();
        for (int i = 0; i < 2; i++) {
            int randomIndex = random.nextInt(randomProducts.length);
            String selectedProduct = randomProducts[randomIndex];
            productsList.add(selectedProduct);
        }

        adapter.notifyDataSetChanged(); // Assuming adapter is used to update a ListView or RecyclerView
    }

    private void deleteProduct() {
        if (productsList.size() > 0) {
            productsList.remove(productsList.size() - 1);
            adapter.notifyDataSetChanged();
        }
    }
}